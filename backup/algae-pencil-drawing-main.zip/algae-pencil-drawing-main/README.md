# Algae Pencil Drawing
Algae pencil drawing, visualization of the beauty of the trigonometric functions.

![](screenshot.jpg)


## Setup
```
% npm install
% npm start
```

Adding `?debug` to the URL will show a parameters pane.


## License
CC-BY-NC-SA 4.0. See [LICENSE](LICENSE.txt) for details.
